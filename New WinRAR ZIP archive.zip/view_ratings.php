<?php
session_start();
include 'db.php';

// Fetch all ratings with corresponding usernames
$sql = "SELECT r.rating, r.comment, r.token, r.created_at, u.username
        FROM ratings r
        JOIN users u ON r.user_id = u.id
        ORDER BY r.created_at DESC";

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Ratings</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #4facfe, #00f2fe);
            color: #333;
            padding: 40px;
            text-align: center;
        }

        .navbar {
            margin-bottom: 40px;
        }

        .navbar a {
            background-color: #005f73;
            color: white;
            text-decoration: none;
            font-size: 20px;
            margin: 10px;
            padding: 10px 20px;
            border-radius: 10px;
            display: inline-block;
        }

        .navbar a:hover {
            background-color: #0a9396;
        }

        h1 {
            font-size: 36px;
            margin-bottom: 30px;
        }

        table {
            margin: auto;
            width: 90%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 15px;
            font-size: 18px;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #00c6ff;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .stars {
            color: #f5c518;
        }
    </style>
</head>
<body>

<div class="navbar">
    <a href="index.php">Home</a>
    <a href="signup.php">Signup</a>
    <a href="login.php">Login</a>
    <a href="logout.php">Logout</a>
    <a href="bookslot.php">Book Slot</a>
</div>

<h1>User Ratings & Feedback</h1>

<table>
    <tr>
        <th>User</th>
        <th>Token</th>
        <th>Rating</th>
        <th>Comment</th>
        <th>Date</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?= htmlspecialchars($row['username']) ?></td>
            <td><?= htmlspecialchars($row['token']) ?></td>
            <td class="stars"><?= str_repeat('⭐', $row['rating']) ?></td>
            <td><?= htmlspecialchars($row['comment']) ?></td>
            <td><?= $row['created_at'] ?></td>
        </tr>
    <?php endwhile; ?>
</table>

</body>
</html>
