<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch user details
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = '$user_id'";
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f4f8;
            text-align: center;
            padding: 50px;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            display: inline-block;
            width: 60%;
        }
        .container h2 {
            font-size: 30px;
        }
        .container p {
            font-size: 18px;
        }
        button {
            padding: 10px 20px;
            background-color: #2193b0;
            color: white;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0984e3;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Welcome, <?php echo $user['username']; ?></h2>
    <p>Email: <?php echo $user['email']; ?></p>
    <p>Member since: <?php echo $user['created_at']; ?></p>
    <p><a href="bookslot.php"><button>Book Parking Slot</button></a></p>
    <p><a href="logout.php"><button>Logout</button></a></p>
</div>

</body>
</html>
