<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Vehicle Parking Service</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to right, #6dd5ed, #2193b0);
            color: white;
            text-align: center;
        }

        nav {
            background-color: rgba(0, 0, 0, 0.3);
            padding: 20px;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin: 0 30px;
            font-size: 22px;
            font-weight: bold;
        }

        nav a:hover {
            text-decoration: underline;
        }

        .container {
            margin-top: 100px;
        }

        h1 {
            font-size: 50px;
            margin-bottom: 20px;
        }

        p {
            font-size: 24px;
            max-width: 800px;
            margin: auto;
        }

        .button {
            margin-top: 30px;
            display: inline-block;
            padding: 15px 30px;
            font-size: 22px;
            color: #2193b0;
            background-color: white;
            border-radius: 10px;
            text-decoration: none;
        }

        .button:hover {
            background-color: #f0f0f0;
        }
    </style>
</head>
<body>

    <nav>
        <a href="signup.php">Signup</a>
        <a href="login.php">Login</a>
    </nav>

    <div class="container">
        <h1>Welcome to Smart Vehicle Parking</h1>
        <p>
            Reserve your parking slot online with ease! Choose your preferred slot, date, and duration. 
            Confirm your booking and get your unique token. Pay offline at the parking center. 
            Enjoy a hassle-free and secure parking experience.
        </p>
        <a href="signup.php" class="button">Get Started</a>
    </div>

</body>
</html>
