<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$message = "";

// Fetch availability
$available_slots = ['A1', 'A2', 'B1', 'B2'];
$slot_availability = [];
$slot_balance = [];

foreach ($available_slots as $slot) {
    $sql_check = "SELECT COUNT(*) AS booked_slots FROM bookings WHERE slot = '$slot'";
    $result = mysqli_query($conn, $sql_check);
    $row = mysqli_fetch_assoc($result);
    $booked_slots = $row['booked_slots'];
    $slot_availability[$slot] = $booked_slots < 10;
    $slot_balance[$slot] = 10 - $booked_slots;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $slot = $_POST['slot'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $duration = $_POST['duration'];
    $vehicle_type = $_POST['vehicle_type'];
    $price = $duration * 100;
    $token = strtoupper(substr(md5(uniqid()), 0, 6));

    if ($slot_availability[$slot]) {
        $sql = "INSERT INTO bookings (user_id, slot, date, time, duration, price, vehicle_type, token)
                VALUES ('$user_id', '$slot', '$date', '$time', '$duration', '$price', '$vehicle_type', '$token')";

        if (mysqli_query($conn, $sql)) {
            $_SESSION['booking_token'] = $token;
            $_SESSION['price'] = $price;
            $_SESSION['slot'] = $slot;
            $_SESSION['date'] = $date;
            $_SESSION['time'] = $time;
            $_SESSION['duration'] = $duration;

            header("Location: confirm_booking.php");
            exit();
        } else {
            $message = "Error: " . mysqli_error($conn);
        }
    } else {
        $message = "Sorry, the selected slot is fully booked.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Book Parking Slot</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #00b09b, #6dc0e0);
            color: #fff;
        }

        .navbar {
            background-color: #004d4d;
            padding: 20px;
            text-align: center;
        }

        .navbar a {
            color: #fff;
            text-decoration: none;
            font-size: 20px;
            margin: 0 20px;
            font-weight: bold;
        }

        .navbar a:hover {
            text-decoration: underline;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 40px;
            gap: 50px;
        }

        .form-container {
            background-color: #ffffffdd;
            color: #333;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            width: 400px;
            text-align: center;
        }

        input, select {
            font-size: 16px;
            margin: 10px;
            padding: 10px;
            width: 100%;
            border: 2px solid #ccc;
            border-radius: 8px;
        }

        button {
            background-color: #00b09b;
            color: white;
            font-size: 18px;
            padding: 10px 20px;
            margin-top: 20px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            background-color: #028f7c;
        }

        .availability {
            background-color: #ffffffcc;
            color: #000;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            width: 250px;
        }

        .availability h3 {
            margin-top: 0;
            color: #004d4d;
        }

        .availability p {
            font-size: 16px;
            margin: 10px 0;
        }

        .error-message {
            color: red;
            font-weight: bold;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<div class="navbar">
    <a href="index.php">Home</a>
    <a href="signup.php">Signup</a>
    <a href="login.php">Login</a>
    <a href="logout.php">Logout</a>
    <a href="view_ratings.php">View Ratings</a>
</div>

<div class="container">
    <div class="form-container">
        <h2>Book a Parking Slot</h2>
        <form method="POST">
            <select name="slot" required>
                <option value="">-- Select Slot --</option>
                <?php foreach ($available_slots as $slot): ?>
                    <?php if ($slot_availability[$slot]): ?>
                        <option value="<?= $slot ?>"><?= $slot ?> (<?= $slot_balance[$slot] ?> left)</option>
                    <?php else: ?>
                        <option value="<?= $slot ?>" disabled><?= $slot ?> (Full)</option>
                    <?php endif; ?>
                <?php endforeach; ?>
            </select>

            <select name="vehicle_type" required>
                <option value="">-- Select Vehicle Type --</option>
                <option value="Car">Car</option>
                <option value="Motorcycle">Motorcycle</option>
                <option value="Truck">Truck</option>
            </select>

            <input type="date" name="date" required>
            <input type="time" name="time" required>

            <select name="duration" required>
                <option value="">-- Duration (hours) --</option>
                <option value="1">1 hour</option>
                <option value="2">2 hours</option>
                <option value="3">3 hours</option>
                <option value="4">4 hours</option>
            </select>

            <button type="submit">Confirm Booking</button>

            <?php if ($message): ?>
                <p class="error-message"><?= $message ?></p>
            <?php endif; ?>
        </form>
    </div>

    <div class="availability">
        <h3>Slot Availability</h3>
        <?php foreach ($slot_balance as $slot => $balance): ?>
            <p><?= $slot ?>: <?= $balance ?> space<?= $balance != 1 ? 's' : '' ?> left</p>
        <?php endforeach; ?>
    </div>
</div>

</body>
</html>
