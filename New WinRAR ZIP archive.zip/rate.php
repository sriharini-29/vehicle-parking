<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['booking_token'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$token = $_SESSION['booking_token'];
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $rating = $_POST['rating'];
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);

    $sql = "INSERT INTO ratings (user_id, token, rating, comment) 
            VALUES ('$user_id', '$token', '$rating', '$comment')";

    if (mysqli_query($conn, $sql)) {
        $message = "Thank you for rating!";
    } else {
        $message = "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Rate Your Experience</title>
    <style>
        body {
            background: linear-gradient(to right,rgb(30, 240, 247),rgb(164, 220, 241));
            font-family: 'Segoe UI', sans-serif;
            text-align: center;
            padding: 40px;
            color: #333;
        }
        form {
            background: white;
            padding: 30px;
            border-radius: 15px;
            display: inline-block;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        }
        select, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 15px;
            font-size: 16px;
            border-radius: 8px;
            border: 1px solid #aaa;
        }
        button {
            margin-top: 20px;
            padding: 10px 30px;
            background:rgb(14, 121, 139);
            border: none;
            font-size: 18px;
            color: white;
            border-radius: 10px;
            cursor: pointer;
        }
        button:hover {
            background:rgb(35, 196, 245);
        }
        .msg {
            margin-top: 20px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h1>Rate Your Parking Experience</h1>

<form method="POST">
    <label for="rating">Rating (1 to 5 Stars):</label><br>
    <select name="rating" required>
        <option value="">-- Select --</option>
        <option value="1">⭐</option>
        <option value="2">⭐⭐</option>
        <option value="3">⭐⭐⭐</option>
        <option value="4">⭐⭐⭐⭐</option>
        <option value="5">⭐⭐⭐⭐⭐</option>
    </select><br>

    <label for="comment">Leave a Comment:</label><br>
    <textarea name="comment" rows="4" placeholder="Share your experience..."></textarea><br>

    <button type="submit">Submit Rating</button>
</form>

<?php if ($message): ?>
    <p class="msg"><?= $message ?></p>
<?php endif; ?>

</body>
</html>
