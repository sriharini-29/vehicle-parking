<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$slot = $_SESSION['slot'] ?? '';
$date = $_SESSION['date'] ?? '';
$time = $_SESSION['time'] ?? '';
$duration = $_SESSION['duration'] ?? '';
$price = $_SESSION['price'] ?? '';
$token = $_SESSION['booking_token'] ?? '';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Booking Confirmation</title>
    <style>
        body {
            background: linear-gradient(to right, #00c6ff, #0072ff);
            font-family: 'Segoe UI', sans-serif;
            color: white;
            text-align: center;
            padding: 50px;
        }
        .card {
            background: white;
            color: #333;
            display: inline-block;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.3);
        }
        h1 {
            color: #fff;
        }
        a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            margin-top: 20px;
            display: inline-block;
            background: #333;
            padding: 10px 20px;
            border-radius: 10px;
        }
    </style>
</head>
<body>

<h1>Booking Confirmed!</h1>

<div class="card">
    <p><strong>Slot:</strong> <?= $slot ?></p>
    <p><strong>Date:</strong> <?= $date ?></p>
    <p><strong>Time:</strong> <?= $time ?></p>
    <p><strong>Duration:</strong> <?= $duration ?> hour(s)</p>
    <p><strong>Price:</strong> ₹<?= $price ?></p>
    <p><strong>Token:</strong> <?= $token ?></p>
    <p><strong>Payment:</strong> Offline Payment Only</p>
    <a href="rate.php">Click here to Rate Your Experience</a>
</div>

</body>
</html>
