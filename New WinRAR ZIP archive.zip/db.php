<?php
$conn = new mysqli("localhost", "root", "", "vehicle_parking");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
